The JSON data file was downloaded from:
https://svs.gsfc.nasa.gov/vis/a000000/a004700/a004768/mooninfo_2020.json

This link is provided in:
https://svs.gsfc.nasa.gov/4768
